export default function Footer () {

  return (
    <>
      <div className="grid p-2 bg-[#F47E36]  justify-center border-b-[1px] border-black	">
        <p className="font-light text-sm	 text-slate-100">Ejes de Comunicación | Leandro N. Alem 1110 7° Piso Capital Federal | Línea rotativa (011) 5352-0550</p>
      </div>
    </>
  )
};