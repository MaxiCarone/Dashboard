export default function Profile() {
  return (
    <div className="mb-8 grid gap-2 p-4 grid-cols-1  md:grid-cols-1 xl:grid-cols-4 xl:grid-rows-[0.5fr 1fr 1fr 1fr]">
      SECCION DE Perfil
    </div>
  )
}
